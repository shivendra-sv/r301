# Multi-agent orchestration demo — Spring PetClinic × Jira × Copilot CLI

One prompt, six agents, five skills, two human gates. A Jira ticket walks itself to a reviewed PR.

**Teaching point:** agents are *roles with permissions*, skills are *reusable procedures*, files are *hand-offs*. Each phase agent is a thin persona that loads exactly one skill; the reviewer is deliberately self-contained, so the audience sees both patterns and can discuss where knowledge should live.

---

## 1. Architecture

| Agent | Loads skill | Tools | May write |
|---|---|---|---|
| `ticket-orchestrator` | `atlassian` (+ inline PR steps) | read, search, edit, execute, agent, atlassian/* | `.agent-work/`, branch, PR |
| `ticket-analyst` | `requirement-analysis` | read, search, edit (no shell) | `plan.md` only |
| `coder` | `coding` | read, search, edit, execute | `src/main/**`, `impl-notes.md` |
| `test-engineer` | `unit-testing` | read, search, edit, execute | `src/test/**`, `test-report.md` |
| `doc-writer` | `documentation` | read, search, edit (no shell) | README/docs/Javadoc, `docs-notes.md` |
| `reviewer` | — (procedure + checklist in its profile) | read, search, edit, execute | `review.md` only |

Pipeline: intake (orchestrator·atlassian) → ticket-analyst → **GATE 1** → coder → test-engineer → doc-writer → reviewer (loop ≤2 via coder + test-engineer) → **GATE 2** → orchestrator publishes PR → Jira updated.

Skills in `.github/skills/<name>/SKILL.md`: `atlassian`, `requirement-analysis` (+ `plan-template.md`), `coding`, `unit-testing`, `documentation`. Shared build knowledge lives in `AGENTS.md` (always-on) with `scripts/verify.sh` as the one-line format→compile→test shortcut every agent uses.

## 2. What's in this kit and where it goes

| Kit path | Copy to | Purpose |
|---|---|---|
| `AGENTS.md` | `<repo>/AGENTS.md` | Conventions + build commands every agent reads first |
| `.github/agents/` (6 files) | `<repo>/.github/agents/` | Agent profiles |
| `.github/skills/` (5 folders) | `<repo>/.github/skills/` | Skills + support files |
| `gitignore-append.txt` | append to `<repo>/.gitignore` | Keeps `.agent-work/` out of commits |
| `copilot-config/mcp-config.json` | `~/.copilot/mcp-config.json` | Atlassian Remote MCP (OAuth). Prefer `/mcp add` in the CLI — it writes this file for you |
| `copilot-config/mcp-config.api-token-fallback.json` | only if OAuth fails | Same server via `mcp-remote` + API token |
| `jira/` | Jira | Ticket text (`PET-101`, `PET-102`) and project setup |
| `scripts/verify.sh` | `<repo>/scripts/` | format-apply → compile → tests, one-line result |
| `scripts/demo-reset.sh`, `scripts/preflight.sh` | `<repo>/scripts/` | Reset between rehearsals; 30-minutes-before health check |

---

## 3. Today — setup in order (~3.5 h including three rehearsals)

### 3.1 Repo (20 min)
```bash
gh repo fork spring-projects/spring-petclinic --clone --default-branch-only
cd spring-petclinic
./mvnw -q package -DskipTests      # warm the Maven cache — cold downloads on venue Wi-Fi will eat the demo
./mvnw -q test                     # green baseline (~1–2 min)
cp -r <kit>/.github/agents <kit>/.github/skills .github/
cp <kit>/AGENTS.md .
cat <kit>/gitignore-append.txt >> .gitignore
mkdir -p scripts && cp <kit>/scripts/*.sh scripts/ && chmod +x scripts/*.sh
bash scripts/verify.sh OwnerControllerTests    # expect: VERIFY: PASS
git add -A && git commit -m "chore: add agent pipeline (6 agents, 5 skills)" && git push
gh auth status                     # PRs target YOUR fork's main
```
Windows: use `mvnw.cmd`; run scripts from Git Bash.

### 3.2 Jira (20 min) — follow `jira/setup.md`
Clone PET-101 three times. Rehearse on the clones; keep the original pristine. Cloning *is* the Jira reset.

### 3.3 Copilot CLI + Atlassian MCP (15 min)
```bash
copilot --version                  # needs ≥ 1.0.11 for Atlassian OAuth
cd spring-petclinic && copilot
/mcp                               # → Add server → name: atlassian · type: http · url: https://mcp.atlassian.com/v1/mcp/
```
Browser opens for Atlassian consent; grant Jira read + write. Then, in the same session:
```
Using the atlassian MCP, fetch PET-103 and print its summary and status.
/skills list                       # expect the 5 skills
/agent                             # expect the 6 agents (restart the CLI if not)
```
A Dynamic-Client-Registration error means the CLI is too old — update it; if it still fails, use the API-token fallback config.

### 3.4 First rehearsal — verify these six things (30 min)
Run on a clone (PET-103), interactively:

1. **Orchestrator sees Jira tools.** Its `tools:` names the MCP as `atlassian/*`. If it says it has no Jira tools, delete the `tools:` line from `ticket-orchestrator.agent.md` (it then inherits everything) — and check the server name in `/mcp` is exactly `atlassian`.
2. **Sub-agents load their skills.** After `▶ Phase 1/6 — ticket-analyst`, the analyst should visibly load `requirement-analysis`. If a sub-agent can't find its skill, the orchestrator injects the SKILL.md body and retries — fine as a fallback, but if it happens every phase, check `/skills info requirement-analysis` and the paths.
3. **Agents stay in their lanes.** Coder writing tests, or test-engineer patching `src/main/` → strengthen the "never" lines in the offending profile. This is the risk of role-sliced agents: coder and test-engineer have identical tools, only instructions separate them.
4. **Permission prompts.** For each prompt choose *"don't ask again in this repo"* — persists to `~/.copilot/permissions-config.json`, so tomorrow is prompt-free. Belt and braces: start with `copilot --allow-all-tools` (throwaway fork).
5. **spring-javaformat.** `format: FAIL` in `review.md` means an agent skipped `verify.sh`/`spring-javaformat:apply`.
6. **Timing.** Expect 15–20 min end-to-end (two full `mvnw test` runs are the bulk). Over 25? Change the reviewer's step 4 to targeted classes.

Then `scripts/demo-reset.sh PET-103`; rehearse on PET-104 and PET-105. **Screen-record the third run** — that's your fallback.

### 3.5 Optional stretch (only if rehearsals are clean)
```bash
copilot --agent ticket-orchestrator --allow-all-tools --prompt "Work ticket PET-105 auto-approve"
```
Verify once that MCP tools are visible in `--prompt` mode; if not, drop the stretch — don't debug it tonight.

---

## 4. Kickoff (what you type tomorrow)

In the **IntelliJ Terminal tool window** (audience sees the editor and git gutter update live; have `.agent-work/PET-101/plan.md` ready to open at Gate 1):

```bash
cd spring-petclinic && scripts/preflight.sh
copilot --allow-all-tools
```
```
/agent          → select ticket-orchestrator
Work ticket PET-101.
```
Gate 1: `yes` (or `changes: also add a hint under the search box` to show steering). Gate 2: `yes`.

Don't run this through the JetBrains Copilot Chat agent picker — custom agents there are still in public preview and sub-agent delegation there is unverified. CLI in the IntelliJ terminal is the proven path.

---

## 5. Session plan — 90 minutes

| Time | Segment | What happens |
|---|---|---|
| 0–10 | **Why orchestrate** | Single-agent failure modes: context bloat, role confusion, no independent review. Your Context Attention Sandbox simulator makes the isolation-trap point in 2 minutes if you want a visual. |
| 10–25 | **Anatomy of the harness** | The four layers: `AGENTS.md` (always-on) → skills (on-demand procedures) → agents (roles with permissions) → MCP (external systems). Open `coder.agent.md` — a dozen lines, deliberately boring — then `coding/SKILL.md`: "the agent is a permission set and a lane; the knowledge is in the skill." Contrast with `reviewer.agent.md`, which is self-contained, and ask the room where they'd draw that line. Show `/skills list`, `/agent`, `~/.copilot/mcp-config.json`. |
| 25–30 | **The ticket** | PET-101 in Jira. The checkbox ACs are the contract: `requirement-analysis` parses them, the reviewer verifies them, the PR body reports them. |
| 30–55 | **Live run** | Kick off. Narrate each banner. **Gate 1:** open `plan.md`, read the AC→file table aloud — requirement mapped to code before a line is written. Approve. While tests run: git gutter in IntelliJ, first Jira comment. **Gate 2:** show `review.md`. Approve. |
| 55–65 | **What came out** | PR page (body assembled from artifacts), Jira comments + In Review, `test-report.md`, the diff. |
| 65–80 | **Design notes / where it breaks** | Below. |
| 80–90 | **Q&A** | |

If the live run stalls: say so, switch to the recording at the failing phase, keep narrating. Nobody minds a fallback; everyone minds dead air.

### Talking points for 65–80 (pick 4–5)
- **Two ways to slice agents: by role or by trust boundary.** This harness slices by role — six agents, very legible. Note the cost: `coder` and `test-engineer` carry identical tools, so only instructions keep them apart. The trust-boundary slice (3 agents: external-systems / writes-source / read-only) is the tighter security story; hooks and path-scoped permissions (`--allow-tool='write(src/test/**)'`) are how you harden either.
- **Where should knowledge live?** Phase agents are thin persona + one skill; the reviewer is self-contained. Rule of thumb: procedures you'll reuse or port → skill; judgement tightly bound to one role's identity → profile. Skills (`SKILL.md`) are the same open format Claude Code and Cursor read — the procedure investment survives a tool change; `.agent.md` wiring is Copilot-specific and small.
- **Files, not chat.** Every hand-off is a markdown file with a fixed schema (templates ship inside the skills). Debuggable, resumable, human-reviewable — and the PR body is assembled from them.
- **Jira lives only in the orchestrator.** Least privilege, plus a known Copilot CLI limitation: MCP servers declared in an agent's frontmatter don't connect when it runs as a sub-agent. Design around the platform.
- **Handoffs vs orchestration.** VS Code's `handoffs:` is a user-clicked relay; the CLI ignores it. Real orchestration is the orchestrator's prompt + the `agent` tool — prompt-driven, so banners and status lines are load-bearing.
- **Gates are where judgement stays human.** Gate 1 catches wrong plans cheaply; Gate 2 is the accountability moment. `auto-approve` is for CI, not people.
- **Cost and non-determinism.** Six fresh contexts, each re-reading `AGENTS.md` + a skill; two full test runs. Same ticket, different plans on different runs — which is why the reviewer verifies against ACs and runs tests itself.

---

## 6. Fallbacks

| Failure | Response |
|---|---|
| Atlassian OAuth / MCP down | Paste PET-101 text into `.agent-work/PET-101/ticket.md` by hand; prompt: `Work ticket PET-101 from the existing ticket.md; skip Jira updates.` Pipeline otherwise identical. |
| Sub-agents can't load skills | Orchestrator injects SKILL.md bodies automatically (built in). Slower, same result. |
| Copilot CLI slow or rate-limited | Switch to recording. |
| Test run hangs | Ctrl-C the tool; tell the orchestrator `continue with targeted tests only`. |
| gh push fails | Show local branch + commit; PR creation is the least interesting part. |
| Total loss | Pre-completed branch `feature/PET-101-demo-backup` + open PR, created in rehearsal 3. |

---

## 7. Morning of

- [ ] `scripts/preflight.sh` passes
- [ ] `copilot` → `/mcp` shows atlassian connected; `/skills list` shows 5; `/agent` shows 6
- [ ] PET-101 is in **To Do** with no comments (the pristine original)
- [ ] Recording opens; backup branch and PR exist
- [ ] IntelliJ: editor top, terminal bottom, font ≥ 16 for the projector
- [ ] Phone hotspot ready as network fallback
